I need to build a bash-only system to submit multiple slurm jobs using a given sbatch file.
the sbatch file will have environment variables, and for different choices of environment variables, I need to run a bunch of jobs.


# Method 1 - run one after other and submit all jobs in one go
```bash
./method_requeuing.sh proteins.txt
./method_workstealing.sh proteins.txt
```